function [choice, loc_pot_minus_1, loc_pot_plus_1] = compute_local_potential(clean_img, noisy_img, row, column, h, beta, eta)

choice = clean_img(row, column);

if (row > 1 && column > 1 && row < size(clean_img,1) && column < size(clean_img,2))
    loc_pot_plus_1 = -(beta*(clean_img(row+1,column)+clean_img(row-1,column)+clean_img(row,column+1)+clean_img(row,column-1)))-eta*(noisy_img(row,column));
    loc_pot_minus_1 = -(beta*(-clean_img(row+1,column)-clean_img(row-1,column)-clean_img(row,column+1)-clean_img(row,column-1)))-eta*(-noisy_img(row,column));
    if (loc_pot_plus_1 < loc_pot_minus_1)
        choice = 1;
    else
        choice = -1;
    end;
end;

if (row == 1 && column > 1 && column < size(clean_img,2))
    loc_pot_plus_1 = -(beta*(clean_img(row+1,column)-1+clean_img(row,column+1)+clean_img(row,column-1)))-eta*(noisy_img(row,column));
    loc_pot_minus_1 = -(beta*(-clean_img(row+1,column)-1-clean_img(row,column+1)-clean_img(row,column-1)))-eta*(-noisy_img(row,column));
    if (loc_pot_plus_1 < loc_pot_minus_1)
        choice = 1;
    else
        choice = -1;
    end;
end;

if (row > 1 && column == 1 && row < size(clean_img,1))
    loc_pot_plus_1 = -(beta*(clean_img(row+1,column)+clean_img(row-1,column)+clean_img(row,column+1)-1))-eta*(noisy_img(row,column));
    loc_pot_minus_1 = -(beta*(-clean_img(row+1,column)-clean_img(row-1,column)-clean_img(row,column+1)-1))-eta*(-noisy_img(row,column));
    if (loc_pot_plus_1 < loc_pot_minus_1)
        choice = 1;
    else
        choice = -1;
    end;
end;

if (column > 1 && row == size(clean_img,1) && column < size(clean_img,2))
    loc_pot_plus_1 = -(beta*(clean_img(row-1,column)-1+clean_img(row,column+1)+clean_img(row,column-1)))-eta*(noisy_img(row,column));
    loc_pot_minus_1 = -(beta*(-clean_img(row-1,column)-1-clean_img(row,column+1)-clean_img(row,column-1)))-eta*(-noisy_img(row,column));
    if (loc_pot_plus_1 < loc_pot_minus_1)
        choice = 1;
    else
        choice = -1;
    end;
end;

if (row > 1 && row < size(clean_img,1) && column == size(clean_img,2))
    loc_pot_plus_1 = -(beta*(clean_img(row+1,column)+clean_img(row-1,column)-1+clean_img(row,column-1)))-eta*(noisy_img(row,column));
    loc_pot_minus_1 = -(beta*(-clean_img(row+1,column)-clean_img(row-1,column)-1-clean_img(row,column-1)))-eta*(-noisy_img(row,column));
    if (loc_pot_plus_1 < loc_pot_minus_1)
        choice = 1;
    else
        choice = -1;
    end;
end;

if (row == 1 && column == 1)
    loc_pot_plus_1 = -(beta*(-1-1+clean_img(row+1,column)+clean_img(row,column+1)))-eta*(noisy_img(row,column));
    loc_pot_minus_1 = -(beta*(-1-1-clean_img(row+1,column)-clean_img(row,column+1)))-eta*(-noisy_img(row,column));
    if (loc_pot_plus_1 < loc_pot_minus_1)
        choice = 1;
    else
        choice = -1;
    end;
end;

if (row == 1 && column == size(clean_img,2))
    loc_pot_plus_1 = -(beta*(-1-1+clean_img(row+1,column)+clean_img(row,column-1)))-eta*(noisy_img(row,column));
    loc_pot_minus_1 = -(beta*(-1-1-clean_img(row+1,column)-clean_img(row,column-1)))-eta*(-noisy_img(row,column));
    if (loc_pot_plus_1 < loc_pot_minus_1)
        choice = 1;
    else
        choice = -1;
    end;
end;

if (row == size(clean_img,1) && column == 1)
    loc_pot_plus_1 = -(beta*(-1-1+clean_img(row-1,column)+clean_img(row,column+1)))-eta*(noisy_img(row,column));
    loc_pot_minus_1 = -(beta*(-1-1-clean_img(row-1,column)-clean_img(row,column+1)))-eta*(-noisy_img(row,column));
    if (loc_pot_plus_1 < loc_pot_minus_1)
        choice = 1;
    else
        choice = -1;
    end;
end;

if (row == size(clean_img,1) && column == size(clean_img,2))
    loc_pot_plus_1 = -(beta*(-1-1+clean_img(row-1,column)+clean_img(row,column-1)))-eta*(noisy_img(row,column));
    loc_pot_minus_1 = -(beta*(-1-1-clean_img(row-1,column)-clean_img(row,column-1)))-eta*(-noisy_img(row,column));
    if (loc_pot_plus_1 < loc_pot_minus_1)
        choice = 1;
    else
        choice = -1;
    end;
end;

end
