% load data
load hw1_images

% pick some parameters
h = 0;
beta = 1.5;
eta = 1.2;

% carry out greedy optimization
cleanImg = noisyImg;
loops = 10; % fixed number of iterations
figure,
for l = 1:loops
    for row = 1 : size(noisyImg,1)
        for col = 1 : size(noisyImg,2)
            cleanImg(row, col) = compute_local_potential(cleanImg,noisyImg,row,col,h,beta,eta);
        end
    end
    disp(['loop = ' num2str(l)]);
    imagesc(cleanImg)
    drawnow
end

% compute number of incorrect pixels
num_pixels_wrong = sum(sum(origImg~=cleanImg));
total_num_pixels = size(origImg,1)*size(origImg,2);
fprintf('The error rate is %g percent.\n',100*(num_pixels_wrong/total_num_pixels));
